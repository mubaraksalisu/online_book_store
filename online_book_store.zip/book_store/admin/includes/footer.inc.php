<div id="footer-wrap">
	<p id="legal">(c) 2018 Bookshop. Design by Musa.</p>
	</div>