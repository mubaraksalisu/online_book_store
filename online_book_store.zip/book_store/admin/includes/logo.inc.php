<marquee  direction="right" behavior="alternate"><h1>Dan Baba Bookstore</h1></marquee>
