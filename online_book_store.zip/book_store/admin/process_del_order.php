<?php

	require('includes/config.php');
			
			$query="DELETE FROM b_order WHERE o_id =".$_GET['sid'];
		
			mysqli_query($conn,$query) or die("can't Execute...");
			
			
			header("location:order.php");

?>